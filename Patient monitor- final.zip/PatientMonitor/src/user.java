import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/user")
public class user extends HttpServlet {

                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                response.setContentType("text/html");
                                PrintWriter out = response.getWriter();
                                
                                String firstname = request.getParameter("fname");
                                String lastname = request.getParameter("lname");
                                String age = request.getParameter("age");
                                String gender = request.getParameter("gender");
                                String email = request.getParameter("email");
                                String contact = request.getParameter("contact");
                                String city = request.getParameter("city");
                                String state = request.getParameter("state");
                                String username = request.getParameter("username");
                                String userid = request.getParameter("uid");
                                String password = request.getParameter("pw");
                                String role = request.getParameter("role");
                                
                                
                                if(firstname.isEmpty()||lastname.isEmpty()||age.isEmpty()||email.isEmpty()||contact.isEmpty()||state.isEmpty()|| username.isEmpty()||userid.isEmpty()||password.isEmpty()|| role.isEmpty())
                                {
                                                RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
                                                out.println("<font color=red>Please fill all the fields</font>");
                                                rd.include(request, response);
                                }
                                else
                                {
                                                // inserting data into mysql database
                                                // create a test database and student table before running this
                                                // to create table -  create table student(name varchar(100), userName varchar(100), pass varchar(100), addr varchar(100), age int, qual varchar(100), percent varchar(100), year varchar(100));

                                                try {
                                                                Class.forName("oracle.jdbc.driver.OracleDriver");
                                                // loads mysql driver
                                                
                                                Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hrs"); // create new connection with test database
                                                
                                                String query="insert into main values(?,?,?,?,?,?,?,?,?,?,?,?)";
                                                
                                                PreparedStatement ps=con.prepareStatement(query);  // generates sql query
                                                
                                                ps.setString(1, firstname);
                                                ps.setString(2, lastname);
                                                ps.setString(3, age);
                                                ps.setString(4, gender);
                                                ps.setString(5, email);
                                                ps.setString(6, contact);
                                                ps.setString(7, city);
                                                ps.setString(8, state);
                                                ps.setString(9, username);
                                                ps.setString(10, userid);
                                                ps.setString(11, password);
                                                
                                                ps.setString(12, role);
                                                
                                                
                                                
                                                ps.executeUpdate(); // execute it on test database
                                           
                                                ps.close();
                                                con.close();
                                                } catch (ClassNotFoundException | SQLException e) {
                                                                // TODO Auto-generated catch block
                                                                e.printStackTrace();
                                                } 
                                                System.out.println("New User created successfully");
                                                RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
                                        		rd.forward(request, response);
                                               
                                }
                }
}
