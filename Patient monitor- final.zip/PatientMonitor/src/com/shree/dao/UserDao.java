package com.shree.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.shree.bean.User;

public class UserDao {
	public static Connection getConnection() {
		Connection con = null;

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "hr", "hrs");
		} catch (Exception e) {
			System.out.println(e);
		}
		return con;
	}

	public static int update(User u) {
		int status = 0;
		try {
			Connection con = UserDao.getConnection();

			PreparedStatement ps = con.prepareStatement("update record set advice=? where userid=?");

			ps.setString(1, u.getAdvice());
			ps.setString(2, u.getUserid());
			System.out.println(u.getAdvice());

			status = ps.executeUpdate();
			System.out.println(status);
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return status;

	}

	public static List<User> getAllRecords() {

		List<User> list = new ArrayList<User>();

		try {
			Connection con = getConnection();

			PreparedStatement ps = con.prepareStatement("select * from record");

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User u = new User();
				u.setUserid(rs.getString("userid"));
				u.setBmi(rs.getString("bmi"));
				u.setDate(rs.getString("date1"));
				u.setTimeoftheday(rs.getString("timeoftheday"));
				u.setGlucose(rs.getString("glucose"));
				u.setRbccount(rs.getString("rbccount"));
				u.setWbccount(rs.getString("wbccount"));
				u.setPlateletscount(rs.getString("plateletscount"));
				
				u.setAdvice(rs.getString("advice"));
				// System.out.println(rs.getString("advice"));
				list.add(u);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}

	public static User getRecordByUserid(String userid) {
		User u = null;
		try {
			Connection con = getConnection();
			PreparedStatement ps = con
					.prepareStatement("select * from record where userid=?");
			ps.setString(1, userid);

			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setUserid(rs.getString("userid"));
				u.setBmi(rs.getString("bmi"));
				u.setDate(rs.getString("date1"));
				u.setTimeoftheday(rs.getString("timeoftheday"));
				u.setGlucose(rs.getString("glucose"));
				u.setRbccount(rs.getString("rbccount"));
				u.setWbccount(rs.getString("wbccount"));
				u.setPlateletscount(rs.getString("plateletscount"));
				
				u.setAdvice(rs.getString("advice"));
				System.out.println(rs.getString("advice"));

			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return u;
	}
}
