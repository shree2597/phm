package com.shree.bean;

public class User {

private String userid,bmi,date,timeoftheday,glucose,rbccount,wbccount,plateletscount,advice;

public String getUserid() {
	return userid;
}

public void setUserid(String userid) {
	this.userid = userid;
}

public String getBmi() {
	return bmi;
}

public void setBmi(String bmi) {
	this.bmi = bmi;
}

public String getDate() {
	return date;
}

public void setDate(String date) {
	this.date = date;
}

public String getTimeoftheday() {
	return timeoftheday;
}

public void setTimeoftheday(String timeoftheday) {
	this.timeoftheday = timeoftheday;
}

public String getGlucose() {
	return glucose;
}

public void setGlucose(String glucose) {
	this.glucose = glucose;
}

public String getRbccount() {
	return rbccount;
}

public void setRbccount(String rbccount) {
	this.rbccount = rbccount;
}

public String getWbccount() {
	return wbccount;
}

public void setWbccount(String wbccount) {
	this.wbccount = wbccount;
}

public String getPlateletscount() {
	return plateletscount;
}

public void setPlateletscount(String plateletscount) {
	this.plateletscount = plateletscount;
}

public String getAdvice() {
	return advice;
}

public void setAdvice(String advice) {
	this.advice = advice;
}




}